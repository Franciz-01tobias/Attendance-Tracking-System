<?php 
$conn=mysqli_connect("localhost","root","","st_attendance");
?>
