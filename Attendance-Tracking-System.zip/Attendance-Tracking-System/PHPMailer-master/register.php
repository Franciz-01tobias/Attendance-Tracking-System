<?php
require "PHPMailerAutoload.php";
$mail = new PHPMailer;
//$mail->SMTPDebug = 3;                               // Enable verbose debug output
//$mail->Debugoutput = 'html';
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'mail.atc.ac.tz';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'non-reply@atc.ac.tz';                 // SMTP username
$mail->Password = '(x7H;ePi3RVu';                           // SMTP password
$mail->WordWrap = 50;
$mail->SMTPSecure = 'tls';                            // Enable ssl encryption, `tls` port no 587 ssl port no 465
$mail->Port = 587;                                    // TCP port to connect to
$mail->addReplyTo('ipt@atc.ac.tz', 'atc.ac.tz');
$mail->addAddress('atcictdept@gmail.com','Baraka ICT');               // Name is optional
$mail->setFrom('non-reply@atc.ac.tz', 'atc.ac.tz');
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Account activation';
//html body
$message="Dear ".$fullname."<br/><br/>".
"Thank you for registering with IPT Management System.<br>".
"To continue with application please activate your account by clicking the link below<br>".
"<a href='http://localhost/atcipt/activate.php?code=$code'> Account Activation</a><br>".
"If you click the above link and it appears to be broken, please copy and paste the link below into a new browser window<br>".
"http://localhost/atcipt/activate.php?code=$code"."<br/><br/>".
"Thank you for using IPT Management System<br>".
"Sincerely,<br>".
"Industrial Liason Office";
$message2="Dear ".$fullname.
"Thank you for registering with IPT Management System.".
"To continue with application please activate your account by clicking the link below ".
"http://localhost/atcipt/activate.php?code=$code".
" If you click the above link and it appears to be broken, please copy and paste the link below into a new browser window ".
"http://localhost/atcipt/activate.php?code=$code".
" Thank you for using IPT Management System".
"Sincerely,".
"Industrial Liason Office";
$mail->Body    = $message;
//plain text for non-HTML mail clients
$mail->AltBody = $message2;

if(!$mail->send()) {
	echo 'Mailer Error: ' . $mail->ErrorInfo;
    $success=base64_encode("There was a problem while processing your application please try again later....");
	//header("location:register.php?xx=$success");
	//die();
					} 
//-----------------------------------------------------------------------------------------------------//							
									if($mail)
									{
									echo 'Mailer Error: ' . $mail->ErrorInfo;
									$insert7="DELETE FROM taarifazaawali WHERE email='$email'";		
									$query7=mysql_query($insert7) ;
									$insert="INSERT INTO taarifazaawali(email,password,status,code,salt,loc) 																										VALUES('$email','$password','Inactive','$code','$salt','Student')";		
									$query=mysql_query($insert) ;
									$insert2="UPDATE students set email='$email',paddress='$contactaddress',mobile='$telephone',mobile2='$telephone2' WHERE regno='$_SESSION[atciptzuser]'";		
									$query2=mysql_query($insert2) ;
									$success=base64_encode("Thank You for Registering,instructions for activating your account has been sent to your email....");
									//header("location:register.php?xx=$success");
									//die();
									}
							
?>