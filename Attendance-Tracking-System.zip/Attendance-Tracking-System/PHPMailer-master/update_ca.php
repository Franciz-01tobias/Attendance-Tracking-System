<?php
session_start();
error_reporting(E_ALL); ini_set('display_errors', 'Off');
if(empty($_SESSION['SMSfname']))
{
header("location:index.php");
die();
}
require_once('db_conn.php');
	header("X-Frame-Options: DENY"); //prevent clickjacking attacks
	header("X-XSS-Protection: 1; mode=block");
	header("X-Content-Type-Options: nosniff");
	header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
	header("Cache-Control: no-cache, no-store, max-age=0, must-revalidate");
	header("Pragma: no-cache");
	header("Expires: 0");
	$coz=mysql_real_escape_string(stripslashes(htmlentities(strip_tags(trim($_GET['c'])))));
	$sem=mysql_real_escape_string(stripslashes(htmlentities(strip_tags(trim($_GET['s'])))));
	$code=mysql_real_escape_string(stripslashes(htmlentities(strip_tags(trim($_GET['sub'])))));
	$tn=mysql_real_escape_string(stripslashes(htmlentities(strip_tags(trim($_GET['testno'])))));
	$yr=mysql_real_escape_string(stripslashes(htmlentities(strip_tags(trim($_GET['yr'])))));
	$msg=mysql_real_escape_string(stripslashes(htmlentities(strip_tags(trim($_GET['xx'])))));
	$stid=mysql_real_escape_string(stripslashes(htmlentities(strip_tags(trim($_GET['stid'])))));
	$newmark=mysql_real_escape_string(stripslashes(htmlentities(strip_tags(trim($_GET['q1'])))));
	$sql="SELECT * FROM results where course='$coz' AND semister='$sem' AND code='$code' AND testno='$tn' AND year='$yr' AND regno='$stid'";
	$result=mysql_query($sql);
	$rows=mysql_fetch_array($result);
	$value= $rows['testmark'];
	$regno= $rows['regno'];
	$type= $rows['type'];
	$keyz= $rows['stname'];
	$sqlz="UPDATE results SET testmark='$newmark' where course='$coz' AND semister='$sem' AND code='$code' AND testno='$tn' AND year='$yr' AND regno='$stid'";
	$resultz=mysql_query($sqlz);
	if($resultz)
				{
				$uid=$_SESSION['uid'];
				$fullname=$_SESSION['SMSfname'];
				$now=date('h:i:s A',time());
				$action="Updatated CA-".$type." from ".$value." marks to ".$newmark." marks-".$code." for student ".$keyz."-".$regno;
				$insert5="INSERT INTO visited_areas(uid,fullname,page,action,time) 																										VALUES('$uid','$fullname','Update CA','$action','$now')";
				$query5=mysql_query($insert5) ;
				}
	//if($query5)
				{
//--------------------------------------------Send Email----------------------------------------------------------//
$msg=base64_encode("CA-".$type."  for ".$keyz."-".$regno." has been updated from ".$value." marks to ".$newmark." marks- Module Code ".$code);
$fname=$_SESSION['SMSfname'];
$email=$_SESSION['SMSemail'];
$fullname=ucwords(ucfirst(strtolower($fname)));
require "../PHPMailer-master/PHPMailerAutoload.php";
$mail = new PHPMailer;
//$mail->SMTPDebug = 3;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'altar30.supremepanel30.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'non-reply@atc.ac.tz';                 // SMTP username
$mail->Password = '(x7H;ePi3RVu';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable ssl encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to
$mail->setFrom('non-reply@atc.ac.tz', 'ATC SMS System');
$mail->addAddress($email);               // Name is optional
$mail->isHTML(true);                                  // Set email format to HTML
$mail->Subject = 'Changes in CA';
//html body
$message="Dear ".$fullname."<br/><br/>".
"You have ".$action."<br>".
"If you are not aware of the above changes report this issue to your HOD and send email to ict@atc.ac.tz or contact HOD-ICT Department"."<br/><br/>".
"Thank you for using ATC SMS System<br>".
"Skills Make the Difference";
$message2="Dear ".$fullname.
" You have ".$action.
" If you are not aware of the above changes report this issue to your HOD and send email to ict@atc.ac.tz or contact HOD-ICT Department".
"Thank you for using ATC SMS System".
"Skills Make the Difference";
$mail->Body    = $message;
//plain text for non-HTML mail clients
$mail->AltBody = $message2;
if(!$mail->send()) {
    $loc="test_view.php?c=$coz&&sub=$code&&s=$sem&&yr=$yr&&testno=$tn&&xx=$msg";
	//echo $loc;
	die();
					} 
//-----------------------------------------------------------------------------------------------------//							
				if($mail)
				{
				$loc="test_view.php?c=$coz&&sub=$code&&s=$sem&&yr=$yr&&testno=$tn&&xx=$msg";
				//echo $loc;
				die();
				}
}		
?>