<?php
require "PHPMailerAutoload.php";

$mail = new PHPMailer;
$mail->SMTPDebug = 4;                               // Enable verbose debug output
$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'altar30.supremepanel30.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'non-reply@atc.ac.tz';                 // SMTP username
$mail->Password = '(x7H;ePi3RVu';                               // SMTP password
//$mail->SMTPSecure = 'tls'; uses  $mail->Port = 465;                         // Enable TLS encryption, `ssl` also accepted
//$mail->SMTPSecure = 'ssl'; uses  $mail->Port = 465;                         
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to
$mail->setFrom('non-reply@atc.ac.tz', 'ESAMI Admission System');
//$mail->addAddress($email);               // Name is optional
$mail->isHTML(true);       
//$mail->addAddress('joe@example.net', 'Joe User');     // Add a recipient
$mail->addAddress('bmtakati@gmail.com');               // Name is optional
//$mail->addReplyTo('info@example.com', 'Information');
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');

//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Email test from SmS';
$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

if(!$mail->send()) {
    echo 'Email could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Email has been sent';
}
?>
